export const enum Conf {
    TokenSecret = "xiaole-AuthToken"
}